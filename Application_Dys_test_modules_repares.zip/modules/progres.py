# Module extrait de l’application originale.
_CODE = compile('afficher_progres(eleve_actif)\n', __file__, "exec")

def render(context):
    exec(_CODE, context)
